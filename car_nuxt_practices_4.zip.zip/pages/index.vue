<script setup>
useHead({
  title :'Car Home Page'
})
</script>
<template>
    <div>
      <CarHero/>
    </div>
  </template>
  