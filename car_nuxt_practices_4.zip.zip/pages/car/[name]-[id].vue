<script setup>
const router = useRoute();
const {lowercase} = useCustom();
useHead({
  title :'Car '+lowercase(router.params.name)
})

// definePageMeta({
//   layout:'custom'
// })
</script>
<template>
 
<!-- CAR DETAIL PAGE -->
<div class="mx-auto mt-4 max-w-7xl space-y-4 px-4 xs:px-8 sm:px-10 lg:px-16 pb-16 w-3/5">
  <div>
    <!-- CAR HERO -->
    <CarDetailHero/>
  </div>
  <!-- CAR HERO -->
  <!-- CAR ATTRIBUTES -->
    <CarDetailAttribute/>
  <!-- CAR ATTRIBUTES -->

  <!-- CAR DESCRISPTION -->
    <CarDetailDescription/>
  <!-- CAR DESCRISPTION -->
  <!-- CAR CONTACT -->
  <CarDetailContact/>
  <!-- CAR CONTACT -->
</div>
<!-- CAR DETAIL PAGE   -->


</template>