<template>
   <!-- NAVBAR -->
   <header class="sticky top-0 z-50 flex justify-between items-center space-x-1 border-b bg-white p-4 shadow-md">
    <NuxtLink class="text-3xl font-mono" to="/">cartrader</NuxtLink>
  </header>
  <!-- NAVBAR -->
  </template>
  