<script setup>
const error = useError()
const handleError =()=>{
    navigateTo("/");
}
</script>
<template>
    <div>
        ERROR {{error.statusCode}}<br/>
        {{ error.statusMessage }}
        <button @click="handleError">Go Back</button>
    </div>
</template>