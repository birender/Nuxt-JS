export const useCustom = () =>{
    function lowercase(str){
        return str+":";
    }

    return { lowercase }
}