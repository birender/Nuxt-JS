<template>
    <div>
        <NavBar/>
    </div>
</template>