<template>
    <div>
        <NavBar/>
      <slot/>
    </div>
  </template>
  