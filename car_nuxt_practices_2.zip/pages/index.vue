<template>
    <div>
      <NavBar/>
      <CarHero/>
    </div>
  </template>
  