<template>
     <div class="mt-5">
    <p class="mb-10">
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Exercitationem
      consequuntur, et saepe sequi, ipsum quisquam iste autem quas vel aperiam
      laboriosam dolorum vero tempore placeat, asperiores alias magni. Nulla,
      dolores.
    </p>
  </div>
</template>