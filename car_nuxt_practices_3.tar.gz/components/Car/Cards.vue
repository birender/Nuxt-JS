<template>
    <!-- CAR CARDS -->
     <div class="w-full">
        <CarCard/>
     </div>
     <!-- CAR CARDS -->
</template>