<template>
    <div>
      <CarCards/>
    </div>
    <!-- CARS PAGE -->
  </template>
  <!-- city/delhi/car/tata 
Both are allowed
http://localhost:3000/city/delhi/car/tata
http://localhost:3000/city/delhi/car/
-->